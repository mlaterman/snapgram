var db = require('./db');


db.createTables();
/*
db.addUser('yao', 'yao Zhao', 'password','1991-01-08 00:11:22', function(err, data){
    if(err) {
	console.log("Fail in adding a user");
	console.log(err)
    }
    else
	console.log("data is ", data);
});
db.getPassword('yao', function(err, passwd){
    if(err)
	console.log(err);
    else
	console.log("Your passwd is ", passwd);
});

db.addPhoto(1,'2013-08-05 00:13:45','lab.jpg', function(err, pid){
    if(err)
	console.log(err);
    else
	console.log('Photo id is ', pid);
});

db.addPath(4, '/home/yao/photos', function(err){
    if(err)
	console.log(err);
    else
	console.log('succeed');
});
db.getPath(4, function(err, path){
    if(err)
	console.log(err);
    else
	console.log('path is ', path);
});
db.addUser('Yang', 'Yang Liu', 'hihi', '2000-11-22 05:23:20', function(err, data){
    if(err)
	console.log(err)
    if(data > 0){
	console.log('Add Yang successfully');
	console.log('UID is ', data);
    }
    else if(data ==-1)
	console.log('Yang alread existed');
    else
	console.log('Error happened');
});

db.follow(2,1, function(err){
    if(err)
	console.log('unable to follow a person');
    else
	console.log('Succeed in following other');
});

/*
db.checkPassword(1,'password', function (err, match){
    if(err)
	throw err;
    else{
	console.log(match);
	if (match)
	    console.log('Match!');
	else
	    console.log('Not match!');
	
    }
	
}) */
/*db.unFollow(9,8, function(err){
    if(err)
	console.log('unable to unfollow a person');
    else
	console.log('Unfollowed');
});
*/

//db.closeDb();
/*db.deletePhoto(1,11,function (err, succeed){
    if (err)
	throw err
    else if (succeed){
	console.log("succeed in deleting it");
    }
})*/

/*db._deleteFromStream(12,function(err){
    if (err)
	throw err;
});*/

/*
db.getFeed(1, function (err,data){
    if(err)
	throw err;
    else
	console.log(data);
});
db.getMyFeed(1, function(err, myFeed){
    if(err) throw err;
    else console.log(myFeed);
});*/
/*
db.checkUserID(0, function (err, data){
    if(err)
	throw err;
    else
	if(data)
	    console.log("exists");
	else
	    console.log("not exist");
});
*/
